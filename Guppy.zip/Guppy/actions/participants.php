<?php
require_once('../config/config.php');

if (isset($_POST['participants'])) :
    if ($_SERVER['REQUEST_METHOD'] === 'POST') :
        $category_id = $_POST['category_id'];
        $event_id = $_POST['event_id'];
        $user_id = $_POST['user_id'];
        if ($_POST['user_id'] != 0) {
            if ($_POST['user_id'] != $_SESSION['user_id']) {
                $check = first('participants', ['category_id' => $category_id, 'user_id' => $user_id]);
                if (empty($check)) {
                    $save = save('participants', ['category_id' => $category_id, 'user_id' => $user_id]);
                    $random = generateRandomString(8);
                    $data2 = [
                        'category_id' => $category_id,
                        'user_id' => $user_id,
                        'entry_code' => $random
                    ];
                    $save2 = save('entries', $data2);
                    $notif = firstJoin('events', [['event_category', 'event_category.event_id', 'events.event_id']], ['events.event_id' => $event_id, 'category_id' => $category_id]);
                    $data3 = [
                        'user_id' => $user_id,
                        'category_id' => $category_id,
                        'notification_value' => 'You have been added to participate to ' . $notif['title'] . ' Event Category(' . $notif['category_name'] . ')',
                        'is_read' => 1,
                        'notif_datetime' => date('Y-m-d h:i:s')
                    ];
                    $save3 = save('notification', $data3);
                    if ($save && $save2) {
                        setFlash('success', 'Participant Added Successfully');
                        redirect('addparticipants', ['category_id' => $category_id, 'event_id' => $event_id]);
                    }
                } else {
                    setFlash('failed', 'Participant Already in this category');
                    redirect('addparticipants', ['category_id' => $category_id, 'event_id' => $event_id]);
                }
            } else {
                setFlash('failed', 'Cannot select yourself');
                redirect('addparticipants', ['category_id' => $category_id, 'event_id' => $event_id]);
            }
        } else {
            setFlash('failed', 'Please Select a Participant');
            redirect('addparticipants', ['category_id' => $category_id, 'event_id' => $event_id]);
        }
    endif;
endif;

if (isset($_GET['removeparticipants'])) :
    $delete = delete('participants', ['participant_id' => $_GET['participant_id']]);
    if ($delete) {
        setFlash('success', 'Participant Removed Successfully');
        redirect('addparticipants', ['category_id' => $_GET['category_id'], 'event_id' => $_GET['event_id']]);
    }
endif;
