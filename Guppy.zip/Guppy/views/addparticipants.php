<?php
require_once('../config/auth.php');
require_once('navbar.php');
$title = firstJoin('event_category', [['events', 'events.event_id', 'event_category.event_id']], ['category_id' => $_GET['category_id']]);
?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center">
        <h3 class="mt-3">Participants in <?= $title['title'] ?>, (<?= $title['category_name'] ?> Category)</h3>
        <div class="back">
            <a href="events_now.php?event_id=<?php echo $_GET['event_id'] ?>&category_id=<?php echo $_GET['category_id'] ?>" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Back</a>
        </div>
    </div>
    <div class="col-md-12 mx-auto mt-3">
        <div class="card border-0 shadow">
            <div class="card-body p-5">
                <form method="post" action="../actions/participants.php">
                    <div class="row mx-auto mb-3">
                        <input type="hidden" name="category_id" value="<?php echo $_GET['category_id'] ?>">
                        <input type="hidden" name="event_id" value="<?php echo $_GET['event_id'] ?>">
                        <div class="col-md-3 mt-2 px-0">
                            <select class="dropme form-control " name="user_id" id="user_id" event-id="<?php echo $_GET['event_id'] ?>">
                                <option value="0">Select Participants Here</option>
                                <?php $users = findAll('users');
                                foreach ($users as $row) :
                                ?>
                                    <option <?php echo isset($_GET['user_id']) && $_GET['user_id'] == $row['user_id'] ? "selected" : ""; ?> value="<?= $row['user_id'] ?>"><?= $row['firstname'] . ' ' . $row['lastname'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 mt-2 px-0 ms-1">
                            <button class="btn btn-primary text-light" type="submit" name="participants"><i class="fa fa-plus-circle"></i> Add</button>
                        </div>
                    </div>
                </form>

                <table class="table" id="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Address</th>
                            <th>Contact</th>
                            <th>Payment</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $participants = joinTable('participants', [['users', 'users.user_id', 'participants.user_id']], ['participants.category_id' => $_GET['category_id']]);
                        foreach ($participants as $row) :
                        ?>
                            <tr>
                                <td><?= $row['firstname'] . ' ' . $row['lastname'] ?></td>
                                <td><?= $row['address'] ?></td>
                                <td><?= $row['contact_number'] ?></td>
                                <?php $payment = firstJoin('payment', [['entries', 'entries.entry_id', 'payment.entry_id']], ['entries.category_id' => $row['category_id'], 'entries.user_id' => $row['user_id']]); ?>
                                <?php if (empty($payment)) { ?>
                                    <td>Added</td>
                                    <td><a href="../actions/participants.php?removeparticipants&participant_id=<?= $row['participant_id'] ?>&event_id=<?php echo $_GET['event_id'] ?>&category_id=<?php echo $_GET['category_id'] ?>" class="btn btn-danger text-light"><i class="fa fa-times"></i> Remove</a></td>
                                <?php } else { ?>
                                    <td>Paid</td>
                                    <td>N/A</td>
                                <?php } ?>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>