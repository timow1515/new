<?php
require_once('../config/auth.php');
require_once('navbar.php');
$category_id = $_GET['category_id'];
$query = "SELECT entries.entry_id, entries.*, users.*, evaluation.evaluation_badge 
          FROM entries
          INNER JOIN users ON users.user_id = entries.user_id
          LEFT JOIN evaluation ON entries.entry_id = evaluation.entry_id
          WHERE entries.category_id = '$category_id'
          ORDER BY CASE WHEN evaluation.evaluation_badge IN (1, 2, 3, 4, 5) THEN evaluation.evaluation_badge ELSE 6 END ASC";
$result = mysqli_query($conn, $query);
$winners = mysqli_fetch_all($result, MYSQLI_ASSOC);
$title = firstJoin('event_category', [['events', 'events.event_id', 'event_category.event_id']], ['category_id' => $_GET['category_id']]);
?>
<div class="container">
    <div class="row mx-auto">
        <div class="d-flex align-items-center justify-content-between">
            <h3 class="mt-3"><i class="fa fa-trophy"></i> Winners of <?= $title['title'] ?>, (<?= $title['category_name'] ?> Category)</h3>
            <div class="back">
                <a href="event_detail.php?event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Back</a>
            </div>
        </div>
    </div>
    <?php foreach ($winners as $row) : ?>
        <div class="row mx-auto">
            <div class="col-md-12 mt-3">
                <div class="card border-0 shadow border mb-3">
                    <div class="card-head px-3 pt-3">
                        <div class="row mx-auto caption-sm mb-1">
                            <div class="d-flex align-items-center">
                                <div class="post-profile me-1">
                                    <img class="img-comments" src="<?php echo $row['profile_picture'] != null ? $row['profile_picture'] : '../public/assets/images/user.jpg' ?>">
                                </div>
                                <p class="m-0"><?= $row['firstname'] . ' ' . $row['lastname'] ?></p>
                            </div>
                            <div class="d-flex align-items-center mt-2">
                                <?php if ($row['evaluation_badge'] == 1 || $row['evaluation_badge'] == 2 || $row['evaluation_badge'] == 3 || $row['evaluation_badge'] == 4 || $row['evaluation_badge'] == 5) : ?>
                                    <div class="post-profile me-1">
                                        <img class="badgerist" src="<?php echo $row['evaluation_badge'] == 1 ? '../public/assets/images/badge/first.png' : ($row['evaluation_badge'] == 2 ? '../public/assets/images/badge/second.png' : ($row['evaluation_badge'] == 3 ? '../public/assets/images/badge/third.png' : ($row['evaluation_badge'] == 4 ? '../public/assets/images/badge/fourth.png' : ($row['evaluation_badge'] == 5 ? '../public/assets/images/badge/fifth.png' :  '../public/assets/images/badge/default.png')))) ?>">
                                    </div>
                                <?php endif; ?>
                                <?php if ($row['evaluation_badge'] == 1 || $row['evaluation_badge'] == 2 || $row['evaluation_badge'] == 3 || $row['evaluation_badge'] == 4 || $row['evaluation_badge'] == 5) : ?>
                                    <p class="m-0"><?php echo $row['evaluation_badge'] == 1 ? '1st Place' : ($row['evaluation_badge'] == 2 ? '2nd Place' : ($row['evaluation_badge'] == 3 ? '3rd Place' : ($row['evaluation_badge'] == 4 ? '4th Place' : ($row['evaluation_badge'] == 5 ? '5th Place' :  'Error')))) ?></p>
                                <?php endif; ?>
                                <p class="m-0 ms-1">(Entry Code: <?= $row['entry_code'] ?>)</p>
                            </div>

                        </div>
                        <?php
                        $find = joinTable('labels', [['evaluation', 'evaluation.evaluation_id', 'labels.evaluation_id']], ['evaluation.entry_id' => $row['entry_id']]);
                        foreach ($find as $label) :
                        ?>
                            <div class="row mx-auto caption-sm px-2">
                                <div class="d-flex align-items-center position-relative text-success">
                                    <i class="fa fa-tag"></i>
                                    <p class="m-0 ms-1"><?= $label['label_value'] ?> </p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="card-body py-1">
                        <div class="row px-3">
                            <?php $video = first('entries_video', ['entry_id' => $row['entry_id']]); ?>
                            <div class="col-md-9 preview-container border shadow rounded mt-3" style="height: 686px;">
                                <video controls class="wideos">
                                    <source src="<?= $video['entry_video_file'] ?>" type="video/mp4">
                                </video>
                            </div>

                            <?php $image_first = first('entries_image', ['entry_id' => $row['entry_id']]); ?>
                            <?php if (!empty($image_first)) : ?>
                                <div class="col-md-3 mt-3 d-flex flex-column">
                                    <?php
                                    $countVid = countResult('entries_video', ['entry_id' => $row['entry_id']]);
                                    ?>
                                    <?php if ($countVid > 0) : ?>
                                        <div class="row px-0 position-relative" style="height: 50%;">
                                            <div class="img-evaluate-cont">
                                                <img class="img-evaluate blured" src="../public/assets/images/video-placeholder.jpg">
                                            </div>
                                            <h5 class="count-display text-center cursor-pointer" data-bs-toggle="modal" data-bs-target="#videos_previews<?= $row['entry_id'] ?>">
                                                <i class="fa fa-plus"></i><?php echo $countVid - 1; ?> more videos<br><br>
                                                <i class="fa fa-eye"></i> View All Videos
                                            </h5>
                                        </div>

                                        <!-- Modal Video -->
                                        <div class="modal fade px-0" id="videos_previews<?= $row['entry_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-fullscreen">
                                                <div class="modal-content bg-transparent">
                                                    <div class="modal-header transparent mt-2">
                                                        <button type="button" class="btn btn-secondary text-light" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close </button>
                                                    </div>
                                                    <div class="modal-body p-0 pb-2">
                                                        <div class="swiper mySwiper">
                                                            <div class="swiper-wrapper">
                                                                <?php $videoss = find_where('entries_video', ['entry_id' => $row['entry_id']]); ?>
                                                                <?php foreach ($videoss as $videos) : ?>
                                                                    <div class="swiper-slide">
                                                                        <video controls class="wideos">
                                                                            <source src="<?= $videos['entry_video_file'] ?>" type="video/mp4">
                                                                        </video>
                                                                    </div>
                                                                <?php endforeach; ?>
                                                            </div>
                                                            <div class="swiper-button-next"></div>
                                                            <div class="swiper-button-prev"></div>
                                                            <div class="swiper-pagination"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <?php $count_image = countResult('entries_image', ['entry_id' => $row['entry_id']]); ?>
                                    <?php if ($count_image > 0) : ?>
                                        <div class="col-md-6 img-post-view px-0 position-relative flex-grow-1">
                                            <h5 class="count-display text-center cursor-pointer" data-bs-toggle="modal" data-bs-target="#pictures_preview<?= $row['entry_id'] ?>">
                                                <i class="fa fa-plus"></i><?php echo $count_image; ?> images<br><br>
                                                <i class="fa fa-eye"></i> View All Images
                                            </h5>
                                            <img class="img-view-now blured" src="<?= $image_first['entry_image_file'] ?>">
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="modal fade px-0" id="pictures_preview<?= $row['entry_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-fullscreen">
                                        <div class="modal-content bg-transparent">
                                            <div class="modal-header transparent mt-2">
                                                <button type="button" class="btn btn-secondary text-light" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close </button>
                                            </div>
                                            <div class="modal-body p-0 pb-2">
                                                <div class="swiper mySwiper">
                                                    <div class="swiper-wrapper">
                                                        <?php $imgs = find_where('entries_image', ['entry_id' => $row['entry_id']]);
                                                        foreach ($imgs as $images) :
                                                        ?>
                                                            <div class="swiper-slide">
                                                                <img class="img-preview-modals" src="<?= $images['entry_image_file'] ?>">
                                                            </div>
                                                        <?php endforeach; ?>
                                                    </div>
                                                    <div class="swiper-button-next"></div>
                                                    <div class="swiper-button-prev"></div>
                                                    <div class="swiper-pagination"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="row mx-auto px-0 like-count" id="like-count<?= $row['entry_id'] ?>" entray-id="<?= $row['entry_id'] ?>">

                        </div>
                        <div class="d-flex align-items-center mt-1">
                            <?php $likes = first('likes', ['user_id' => $_SESSION['user_id'], 'entry_id' => $row['entry_id']]); ?>
                            <button class="btn border me-1 likebutton <?php echo !empty($likes) ? 'text-primary' : ''; ?>" entrys-id="<?= $row['entry_id'] ?>" id="like<?= $row['entry_id'] ?>" userys-id="<?php echo $_SESSION['user_id'] ?>">
                                <i class="fa fa-thumbs-up" style="transform: scaleX(-1);" style="font-size:18px"></i> <span class="ms-1">Like</span>
                            </button>
                            <a href="individual_winner.php?entry_id=<?= $row['entry_id'] ?>&category_id=<?php echo $_GET['category_id'] ?>" class="btn border">
                                <i class="fa fa-comment" style="transform: scaleX(-1);" style="font-size:18px"></i> <span class="ms-1">Comment</span>
                            </a>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="d-flex">
                            <p class="m-0"><i class="fa fa-comment"></i> Comment Section</p>
                        </div>

                        <div class="row mx-auto mt-3 comment-container" id="comment-container<?= $row['entry_id']; ?>" entries-id="<?= $row['entry_id'] ?>" category-id="<?php echo $_GET['category_id'] ?>">
                            <!-- Send By AJAX comments ugh -->
                        </div>

                        <div class="row mx-auto bg-white py-2 border rounded">
                            <div class="d-flex align-items-center">
                                <div>
                                    <div class="post-profile me-1">
                                        <img class="img-comments" src="<?php echo $_SESSION['profile_picture'] != null ? $_SESSION['profile_picture'] : '../public/assets/images/user.jpg' ?>">
                                    </div>
                                </div>
                                <div style="flex:1">
                                    <input class="form-control" placeholder="Say something..." id="postValue<?= $row['entry_id'] ?>">
                                </div>
                                <div>
                                    <button class="btn btn-primary text-light ms-2 sendPost" type="button" id="sendPost<?= $row['entry_id'] ?>" user-id="<?php echo $_SESSION['user_id'] ?>" entry-id="<?= $row['entry_id'] ?>"><i class="fa fa-paper-plane"></i> <span class="sm-post">Post</span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach ?>
</div>
<?php require_once('footer.php'); ?>