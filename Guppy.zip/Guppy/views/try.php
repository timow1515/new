<?php
require_once('../config/auth.php');
require_once('navbar.php');
$check = first('entries', ['category_id' => $_GET['category_id'], 'user_id' => $_SESSION['user_id']]);
$events = joinTable('events', [['users', 'users.user_id', 'events.user_id'], ['event_category', 'event_category.event_id', 'events.event_id'], ['entries', 'entries.category_id', 'event_category.category_id']], ['event_category.category_id' => $_GET['category_id'], 'events.user_id' => $_SESSION['user_id']]);
$user = first('users', ['user_id' => $_SESSION['user_id']]);
?>
<div class="container position-relative" id="container-evaluate">
    <div class="row mx-auto mb-3">
        <div class="d-flex justify-content-between mt-2">
            <div class="back">
                <a href="event_detail.php?event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Back</a>
            </div>

            <?php if (empty($events)) : ?>
                <?php if (empty($check) || $check['entry_file'] == null) { ?>
                    <h6 class="m-0 me-1 "><i>Looks like you are a participant and didn`t upload a video</i></h6>
                    <div class="form-group">
                        <a href="uploadVideos.php?event_id=<?php echo $_GET['event_id'] ?>&category_id=<?php echo $_GET['category_id'] ?>" class="btn btn-primary text-light">Add Video</a>
                    </div>
                <?php } ?>
            <?php endif; ?>

            <?php if (!empty($events)) : ?>
                <?php $showReport = firstJoin('entries', [['evaluation', 'entries.entry_id', 'evaluation.entry_id']], ['entries.category_id' => $_GET['category_id']]); ?>
                <?php if (!empty($showReport)) : ?>
                    <?php $checkingStats = first('event_category', ['category_id' => $_GET['category_id'], 'category_status' => 1]); ?>
                    <?php if (empty($checkingStats)) { ?>
                        <a href="../actions/event.php?PostResult&category_id=<?php echo $_GET['category_id'] ?>&event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-info text-light"><i class="fa fa-check"></i> Post Results</a>
                    <?php } else { ?>
                        <h4><i class="fa fa-check"></i> Result Posted</h4>
                    <?php }  ?>

                <?php endif; ?>
                <?php if (empty($checkingStats)) : ?>
                    <a href="addparticipants.php?category_id=<?php echo $_GET['category_id'] ?>&event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-primary text-light"><i class="fa fa-plus-circle"></i> Participants</a>
                <?php endif; ?>
            <?php endif; ?>

        </div>
    </div>
    <?php if (!empty($check) && isset($check['entry_file']) && $check['entry_file'] !== null && $check['user_id'] == $_SESSION['user_id']) { ?>
        <div class="row mx-auto">
            <div class="m-0 mt-1 p-0 mb-2 d-flex align-items-center">
                <div class="profile">
                    <img class="img-view" src="<?php echo $_SESSION['profile_picture'] != null ? $_SESSION['profile_picture'] : '../public/assets/images/user.jpg' ?>">
                </div>
                <p class="m-0 ms-1"><?= $user['firstname'] . ' ' . $user['lastname'] ?> (You)</p>
            </div>
            <div class="preview-containers col-md-7 border shadow rounded px-0">
                <video controls class="wideos">
                    <source src="<?= $check['entry_file'] ?>" type="video/mp4">
                </video>
            </div>
        </div>
    <?php } else if (!empty($check) && $check['entry_file'] == null && $check['user_id'] == $_SESSION['user_id']) {
    } else { ?>
        <?php $entries = joinTable('events', [['event_category', 'event_category.event_id', 'events.event_id'], ['participants', 'participants.category_id', 'event_category.category_id'], ['users', 'users.user_id', 'participants.user_id'], ['entries', 'entries.user_id', 'participants.user_id']], ['event_category.category_id' => $_GET['category_id'], 'entries.category_id' => $_GET['category_id']]); ?>
        <?php var_dump($entries) ?>
        <div class="row mx-auto">
            <?php foreach ($entries as $row) : ?>
                <?php if ($row['entry_file'] != null) : ?>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="d-flex justify-content-center">
                                <div>
                                    hey
                                    <div class="m-0 mt-5  p-0 mb-2 d-flex align-items-center">
                                        <div class="profile">
                                            <img class="img-view" src="<?php echo $row['profile_picture'] != null ? $row['profile_picture'] : '../public/assets/images/user.jpg' ?>">
                                        </div>
                                        <div>
                                            <p class="m-0 ms-1"><?= $row['firstname'] . ' ' . $row['lastname'] ?></p>
                                        </div>
                                        <i class="ms-1" style="font-size:13px"> (Entry Code: <strong><?= $row['entry_code'] ?></strong>)</i>

                                    </div>
                                    <div class="preview-containers col-md-7 border rounded">
                                        <video controls class="wideos">
                                            <source src="<?= $row['entry_file'] ?>" type="video/mp4">
                                        </video>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer bg-white mt-3 px-5 py-2">
                                <div class="d-flex justify-content-between align-items-center">
                                    <p class="m-0">Entry Code: <strong><?= $row['entry_code'] ?></strong></p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <?php $checkingStats = first('event_category', ['category_id' => $_GET['category_id'], 'category_status' => 1]); ?>
                                        <?php if (empty($checkingStats)) { ?>
                                            <button class="btn btn-secondary btn-sm py-1 evaluate" type="button" data-bs-toggle="modal" data-bs-target="#evaluate<?= $row['entry_id'] ?>"><i class="fa fa-ribbon"></i> Evaluate</button>
                                        <?php } else { ?>
                                            <button class="btn btn-secondary btn-sm py-1 evaluate px-4" type="button" disabled> N/A</button>
                                        <?php } ?>

                                        <div class="ms-1 container-evaluate d-flex justify-content-center align-items-center border border-info shadow">
                                            <?php $check_badge = first('evaluation', ['entry_id' => $row['entry_id']]); ?>
                                            <img class="img-badge" src="<?php echo !empty($check_badge) && $check_badge['evaluation_badge'] == 1 ? '../public/assets/images/badge/first.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 2 ? '../public/assets/images/badge/second.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 3 ? '../public/assets/images/badge/third.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 4 ? '../public/assets/images/badge/fourth.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 5 ? '../public/assets/images/badge/fifth.png' :  '../public/assets/images/badge/default.png')))) ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal fade" id="evaluate<?= $row['entry_id'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Evaluate <?= $row['firstname'] . ' ' . $row['lastname'] ?> Entry <br>
                                        <i class="ms-1" style="font-size:13px"> (Entry Code: <strong><?= $row['entry_code'] ?></strong>)</i>
                                    </h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <form method="post" action="../actions/evaluate.php">
                                    <input type="hidden" name="entry_id" value="<?= $row['entry_id'] ?>">
                                    <input type="hidden" name="event_id" value="<?php echo $_GET['event_id'] ?>">
                                    <input type="hidden" name="category_id" value="<?php echo $_GET['category_id'] ?>">
                                    <div class="modal-body">
                                        <div class="row mx-auto mb-3">
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="placement" value="1" id="flexRadioDefault1" checked>
                                                    <label class="form-check-label" for="flexRadioDefault1">
                                                        1st Place
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="placement" value="2" id="flexRadioDefault2">
                                                    <label class="form-check-label" for="flexRadioDefault2">
                                                        2nd Place
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mx-auto mb-3">
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="placement" value="3" id="flexRadioDefault3">
                                                    <label class="form-check-label" for="flexRadioDefault3">
                                                        3rd Place
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="placement" value="4" id="flexRadioDefault4">
                                                    <label class="form-check-label" for="flexRadioDefault4">
                                                        4th Place
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mx-auto">
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="placement" value="5" id="flexRadioDefault5">
                                                    <label class="form-check-label" for="flexRadioDefault5">
                                                        5th Place
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio" name="placement" value="0" id="flexRadioDefault5">
                                                    <label class="form-check-label" for="flexRadioDefault5">
                                                        Default
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mx-auto mt-3 p-0 labels" id="labels<?= $row['entry_id'] ?>" entry-id="<?= $row['entry_id'] ?>">
                                            <!-- Send by Ajax Content -->
                                        </div>
                                        <div class="row mx-auto mt-3 p-0" id="row-cloned">
                                            <div id="row-of-form" class="col-md-12 px-0 mb-1">
                                                <div class="form-group">
                                                    <label>Label</label>
                                                    <div class="d-flex align-items-center position-relative justify-content-between g-0">
                                                        <input class="form-control" placeholder="Best in ..." name="label[]" id="label">
                                                        <i class="fa fa-times remove text-danger cursor-pointer position-absolute" style="display: none; right:0; margin-right:10px"></i>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group d-flex justify-content-end mb-3 px-0">
                                            <button class="btn btn-secondary btn-sm text-light" type="button" id="addlabel"><i class="fa fa-plus-circle text-size"></i> Label</button>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="submit" name="evaluate" class="btn btn-primary text-light">Evaluate</button>
                                        </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    <?php } ?>
</div>
<?php require_once('footer.php'); ?>