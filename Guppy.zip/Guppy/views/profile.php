<?php
require_once('../config/auth.php');
require_once('navbar.php'); ?>
<div class="container">
    <div class="row mx-auto mt-3">
        <div class="col-md-12 mx-auto mb-5">
            <div class="card border-0 shadow border">
                <div class="card-header bg-white">
                    <h4 class="my-1"><i class="fa fa-user"></i> Update Profile</h4>
                </div>
                <div class="card-body p-5">
                    <div class="row mx-auto mb-4">
                        <div class="border position-relative px-0 overflow-hidden shadow rounded-circle d-flex justify-content-center" style="height:200px; width:200px">
                            <img class="profile-view" src="<?php echo $_SESSION['profile_picture'] != null ? $_SESSION['profile_picture'] : '../public/assets/images/user.jpg' ?>">
                            <i class="fa fa-camera position-absolute bottom-0 border p-2 rounded-circle bg-white mb-2 text-info cursor-pointer" data-bs-toggle="modal" data-bs-target="#profilepic"></i>
                        </div>
                    </div>
                    <form method="post" action="../actions/updateprofile.php">
                        <div class="row mx-auto mb-3">
                            <div class="col-md-6">
                                <input name="user_id" type="hidden" value="<?php echo $_SESSION['user_id'] ?>">
                                <div class="form-group">
                                    <label>Firstname</label>
                                    <input class="form-control" value="<?php echo $_SESSION['firstname'] ?>" name="firstname">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Lastname</label>
                                    <input class="form-control" value="<?php echo $_SESSION['lastname'] ?>" name="lastname">
                                </div>
                            </div>
                        </div>
                        <div class="row mx-auto mb-3">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email</label>
                                    <input class="form-control" value="<?php echo $_SESSION['email'] ?>" name="email">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Address</label>
                                    <input class="form-control" value="<?php echo $_SESSION['address'] ?>" name="address">
                                </div>
                            </div>
                        </div>
                        <div class="row mx-auto">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Contact Number</label>
                                    <input class="form-control" value="<?php echo $_SESSION['contact_number'] ?>" name="contact_number">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Password <i style="font-size: 12px;">(Leave empty if do not want to update password)</i></label>
                                    <input class="form-control" name="password">
                                </div>
                            </div>
                        </div>
                        <div class="row mx-auto mt-3">
                            <div class="form-group">
                                <button class="btn btn-primary text-light" name="updateprofile" type="submit"><i class="fa fa-edit"></i> Update Profile</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="profilepic" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Profile Picture</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="post" action="../actions/updateprofile.php" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="row mx-auto">
                            <div class="profilepicture rounded-circle border shadow mx-auto overflow-hidden px-0">
                                <img class="profile-view" src="<?php echo $_SESSION['profile_picture'] != null ? $_SESSION['profile_picture'] : '../public/assets/images/user.jpg' ?>">
                            </div>
                            <div class="form-group px-5 mt-3">
                                <input class="form-control" type="file" id="profile" name="profile">
                                <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id'] ?>">
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="profilepic" class="btn btn-primary text-light"><i class="fa fa-save"></i> Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>