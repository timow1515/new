<?php
require_once('../config/auth.php');
require_once('navbar.php');
$categories = firstJoin('event_category', [['events', 'events.event_id', 'event_category.event_id'], ['users', 'users.user_id', 'events.user_id']], ['events.event_id' => $_GET['event_id'], 'category_id' => $_GET['category_id']]);
?>
<div class="container">
    <div class="row mx-auto">
        <h3 class="mt-3">Payments on <?= $categories['title'] ?> (<?= $categories['category_name'] ?> Category)</h3>
    </div>

    <div class="row mx-auto">
        <div class="col-md-12 mx-auto">
            <div class="card border-0 shadow mb-5">
                <div class="card-body p-5">

                    <div class="row mx-auto">
                        <div class="col-md-4">
                            <img class="img-fluid" src="../public/assets/images/payments.png">
                        </div>
                        <div class="col-md-8 mt-4">
                            <div class="row mx-auto mb-4">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Firstname</label>
                                        <input class="form-control" value="<?= $categories['firstname'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Lastname</label>
                                        <input class="form-control" value="<?= $categories['lastname'] ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="row mx-auto mb-4">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Event Title</label>
                                        <input class="form-control" value="<?= $categories['title'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Event Category</label>
                                        <input class="form-control" value="<?= $categories['category_name'] ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="row mx-auto mb-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input class="form-control" value="<?= $categories['email'] ?>" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Contact Number</label>
                                        <input class="form-control" value="<?= $categories['contact_number'] ?>" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mx-auto">
                        <div class="col-md-6 offset-md-3">
                            <div class="row mx-auto mb-4">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Payment Amount</label>
                                        <input class="form-control" value="₱ <?= $categories['payment_amount'] ?>" id="price" price-now="<?= $categories['payment_amount'] ?>" category-id="<?php echo $_GET['category_id'] ?>" event-id="<?php echo $_GET['event_id'] ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="row mx-auto">
                                <div class="form-group">
                                    <div class="row mx-auto">
                                        <!-- <p class="total m-0 p-0 d-flex justify-content-between align-items-center mb-2">Total Price:<strong>₱ <?= $categories['payment_amount'] ?></strong></p> -->
                                        <div id="paypal-button-container" class="px-0"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php require_once('paymentfooter.php'); ?>