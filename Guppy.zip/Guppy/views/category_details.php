<?php
require_once('../config/auth.php');
require_once('navbar.php');
$event = firstJoin('events', [['event_category', 'event_category.event_id', 'events.event_id']], ['event_category.category_id' => $_GET['category_id']]);
$participants = joinTable('participants', [['event_category', 'event_category.category_id', 'participants.category_id'], ['users', 'users.user_id', 'participants.user_id'], ['entries', 'users.user_id', 'entries.user_id']], ['event_category.category_id' => $_GET['category_id'], 'entries.category_id' => $_GET['category_id']]);
?>
<div class="container">
    <div class="row mx-auto mt-3">
        <div class="col-md-12">
            <div class="card border-0 shadow border p-4">
                <div class="card-header bg-white pt-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class=""><i class="fa fa-calendar"></i> Participants of <?= $event['title'] ?>(<?= $event['category_name'] ?>)</h3>
                        <div class="back">
                            <a href="event_category.php?event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Back</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table" id="table">
                        <thead>
                            <tr>
                                <th class="d-none"></th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Address</th>
                                <th>Contact</th>
                                <th>Payment</th>
                                <th>Position</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($participants as $row) : ?>
                                <tr>
                                    <td class="d-none"><?php echo $no;
                                                        $no++; ?></td>
                                    <td><?= $row['firstname'] . ' ' . $row['lastname'] ?></td>
                                    <td><?= $row['email'] ?></td>
                                    <td>₱ <?= $row['address'] ?></td>
                                    <td><?= $row['contact_number'] ?></td>
                                    <?php $payment = first('payment', ['entry_id' => $row['entry_id']]); ?>
                                    <td><?php echo !empty($payment) ? 'Paid' : 'Added' ?></td>
                                    <?php $positions = first('evaluation', ['entry_id' => $row['entry_id']]); ?>
                                    <?php if (!empty($positions)) { ?>
                                        <td>
                                            <div style="height:30px; width:30px">
                                                <img class="img-badge" src="<?php echo $positions['evaluation_badge'] == 1 ? '../public/assets/images/badge/first.png' : ($positions['evaluation_badge'] == 2 ? '../public/assets/images/badge/second.png' : ($positions['evaluation_badge'] == 3 ? '../public/assets/images/badge/third.png' : ($positions['evaluation_badge'] == 4 ? '../public/assets/images/badge/fourth.png' : ($positions['evaluation_badge'] == 5 ? '../public/assets/images/badge/fifth.png' :  '../public/assets/images/badge/default.png')))) ?>">
                                            </div>
                                        </td>
                                    <?php } else {
                                        echo '<td>None</td>';
                                    } ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>