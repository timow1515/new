<?php
require_once('../config/config.php');
?>

<!DOCTYPE html>
<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <title>Register</title>
</head>

<body class="bg-secondary">
    <div class="col-md-5 mx-auto bg-light p-5 mt-4 rounded">
        <h2>Register</h2>

        <!-- Registration form -->
        <form action="../actions/register.php" method="POST">

            <div class="form-group mb-2">
                <label>Firstname</label>
                <input type="text" name="firstname" class="form-control" placeholder="First Name" required>
            </div>

            <div class="form-group mb-2">
                <label>Lastname</label>
                <input type="text" name="lastname" class="form-control" placeholder="Last Name" required>
            </div>

            <div class="form-group mb-2">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Email" required>
            </div>

            <div class="form-group mb-2">
                <label>Address</label>
                <input type="text" name="address" class="form-control" placeholder="Address" required>
            </div>

            <div class="form-group mb-2">
                <label>Contact</label>
                <input type="text" name="contact_number" class="form-control" placeholder="Contact Number" required>
            </div>

            <div class="form-group mb-3">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>
            <div class="form-group">
                <div class="row mx-auto">
                    <button type="submit" name="register" class="btn btn-primary">Register</button>
                    <p class="text-center text-dark mt-2">Already have an account? <a href="login.php">Login</a></p>
                </div>
            </div>

        </form>


    </div>
</body>

</html>