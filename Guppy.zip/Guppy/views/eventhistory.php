<?php
require_once('../config/auth.php');
require_once('navbar.php'); ?>
<div class="container">
    <div class="row mx-auto mt-3">
        <div class="col-md-12">
            <div class="card border-0 shadow border p-4">
                <div class="card-header bg-white pt-3">
                    <h3 class=""><i class="fa fa-calendar"></i> Event Created History</h3>
                </div>
                <div class="card-body">
                    <table class="table" id="table">
                        <thead>
                            <tr>
                                <th class="d-none"></th>
                                <th>Event Title</th>
                                <th>Event Description</th>
                                <th>No. of Categories</th>
                                <th>Date</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $history = find_where('events', ['user_id' => $_SESSION['user_id']], null, ['event_id' => 'ASC']); ?>
                            <?php
                            $no = 1;
                            foreach ($history as $row) : ?>
                                <tr>
                                    <td class="d-none"><?php echo $no;
                                                        $no++; ?></td>
                                    <td><?= $row['title'] ?></td>
                                    <td><?= $row['description'] ?></td>
                                    <?php $count_category = countResult('event_category', ['event_id' => $row['event_id']]); ?>
                                    <td><?= $count_category ?></td>
                                    <td><?php echo date('M d, Y h:i:s a', strtotime($row['date'])); ?></td>
                                    <td><a href="event_category.php?event_id=<?= $row['event_id'] ?>" class="btn btn-primary text-light px-4"><i class="fa fa-eye"></i> View</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>