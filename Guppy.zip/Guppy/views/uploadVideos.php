<?php
require_once('../config/auth.php');
require_once('navbar.php');
$categories = firstJoin('event_category', [['events', 'events.event_id', 'event_category.event_id']], ['events.event_id' => $_GET['event_id'], 'category_id' => $_GET['category_id']]);
$check = first('entries', ['category_id' => $_GET['category_id'], 'user_id' => $_SESSION['user_id']]);
?>
<div class="container">
    <h3 class="mt-3">Upload Video on <?= $categories['title'] ?> (<?= $categories['category_name'] ?> Category)</h1>
        <form action="../actions/entries.php" method="post" enctype="multipart/form-data">
            <input type="hidden" value="<?php echo !empty($check) ? $check['entry_id'] : $_GET['entry_id']; ?>" name="entry_id">
            <input type="hidden" value="<?php echo $_GET['category_id'] ?>" name="category_id">
            <input type="hidden" value="<?php echo $_GET['event_id'] ?>" name="event_id">
            <div class="form-group my-1 mt-3">
                <p class="m-0">Entry Code: <strong><?php echo !empty($check) ? $check['entry_code'] : $_GET['entry_code']; ?></strong> <span><i>(Put this on your video)</i></span></p>
                <div class="d-flex">
                    <button class="btn btn-secondary" type="button" data-bs-toggle="modal" data-bs-target="#help">How <i class="fa fa-question-circle"></i></button>
                    <!-- <p class="m-0"><i style="font-size: 13px;">Click help to Understand rules in Uploading Entries</i></p> -->
                </div>
            </div>
            <div class="row mt-3">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="video-file">Select a video file: <i style="font-size:13px">(Hold Ctrl to multiselect videos)</i></label>
                        <input type="file" required class="form-control" id="video-file" name="entry_video[]" multiple="multiple" accept="video/*">
                    </div>
                    <div class="progress mb-3 mt-3" style="display: none;">
                        <div id="progress-bar" class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" style="width: 0%"></div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Select image: <i style="font-size:13px">(Hold Ctrl to multiselect images)</i></label>
                        <input type="file" class="form-control" id="image-file" name="entry_image[]" multiple="multiple" accept="image/*">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="preview-container col-md-7 border shadow rounded mt-3" style="display: none;">
                        <video id="video-preview" controls class="wideos"></video>
                    </div>
                    <div class="angle-buttons mt-1">
                        <button id="prev-button" type="button" class="btn btn-primary text-light" onclick="prevVideo()"><i class="fa fa-angle-left"></i> Previous</button>
                        <button id="next-button" type="button" class="btn btn-primary text-light" onclick="nextVideo()">Next <i class="fa fa-angle-right"></i></button>
                    </div>
                </div>
                <div class="col-md-6">
                    <div id="preview-container-img" class="mt-3">
                        <div id="slider-wrapper">
                            <div id="slider">
                            </div>
                        </div>
                        <button id="prev-btn" type="button" class="slider-btn btn text-light"><i class="fa fa-angle-left"></i></button>
                        <button id="next-btn" type="button" class="slider-btn btn text-light"><i class="fa fa-angle-right"></i></button>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary my-3 text-light" name="uploadvideos"><i class="fa fa-upload"></i> Upload</button>
        </form>
</div>

<!-- Help Modal -->

<!-- Modal -->
<div class="modal fade" id="help" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="fa fa-question-circle"></i> How to Upload Correct Entry?</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="m-0 mb-3">1. Put the Entry Code to a bondpaper.</p>
                <p class="m-0 mb-3">2. Put the entry code to your aquarium where we can see it.</p>
                <p class="m-0 mb-3">3. Capture a video of your guppy where we can also see the entry code.</p>
                <p class="m-0 mb-3">4. Add Images for your entry (minimum of 2).</p>
                <p class="m-0 mb-3">5. Click Upload Button</p>
                <p class="m-0 mb-3">6. Wait for it to be Uploaded</p>
                <p class="m-0">7. Wait for the Results to be posted at the end of event</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close</button>
            </div>
        </div>
    </div>
</div>

<?php require_once('footer.php'); ?>