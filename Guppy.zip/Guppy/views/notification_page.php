<?php
require_once('../config/auth.php');
require_once('navbar.php'); ?>
<div class="container">
    <div class="col-md-12 mt-3">
        <div class="card p-4 border-0 shadow border">
            <div class="card-header bg-white">
                <h4 class="mt-3"><i class="fa fa-bell"></i> Notifications</h4>
            </div>
            <div class="card-body">
                <table class="table" id="table">
                    <thead>
                        <tr>
                            <th class="d-none"></th>
                            <th>Notification</th>
                            <th>Date</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $notif = find_where('notification', ['user_id' => $_SESSION['user_id']], null, ['notification_id' => 'DESC']);
                        $no = 1;
                        foreach ($notif as $row) :
                        ?>
                            <tr class="<?php echo $row['is_read'] == 1 ? 'unread' : '' ?>">
                                <td class="d-none"><?php echo $no;
                                                    $no++; ?></td>
                                <td><?= $row['notification_value'] ?></td>
                                <td><?php echo date('M d, Y h:i:s', strtotime($row['notif_datetime'])) ?></td>
                                <?php $redirect = firstJoin('events', [['event_category', 'event_category.event_id', 'events.event_id']], ['category_id' => $row['category_id']]); ?>
                                <td><a class="btn btn-primary text-light" href="../actions/redirect.php?event_id=<?= $redirect['event_id'] ?>&category_id=<?= $redirect['category_id'] ?>&notification_id=<?= $row['notification_id'] ?>"><i class="fa fa-eye"></i> View</a></td>
                            </tr>
                        <?php endforeach; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>