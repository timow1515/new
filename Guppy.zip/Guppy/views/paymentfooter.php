</div>
<script src="https://www.paypal.com/sdk/js?client-id=AXlCFZ3lSzHXXqTF9m8VYjwfgw9-H4-s3VYhPGaJvUakF2y1hGmpA5z31himoZ5iF2SxCxiKjlrT4K2F&currency=PHP"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script src="../public/assets/plugins/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="../public/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="../public/assets/plugins/chart.js/chart.min.js"></script>
<script src="../public/assets/js/index-charts.js"></script>
<script src="../public/assets/js/app.js"></script>
<script src="../public/assets/js/main.js"></script>
<script src="../public/assets/js/ajax.js"></script>
<script src="../public/assets/js/paypal.js"></script>
<script src="../public/assets/js/video.js"></script>
<script src="../public/assets/js/notification.js"></script>

<script>
    $(document).ready(function() {
        $('#table').DataTable();
    });



    $(document).ready(function() {
        $('.dropme').select2();
    });
    $(document).ready(function() {
        $('.select2-container').addClass('form-controls');
    })
</script>
<?php if ($flash = getFlash('success')) : ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: "<?php echo $flash; ?>",
            showConfirmButton: true,
        });
    </script>
<?php endif; ?>

<?php if ($flash = getFlash('failed')) : ?>
    <script>
        Swal.fire({
            icon: 'warning',
            title: "<?php echo $flash; ?>",
            showConfirmButton: true,
        });
    </script>
<?php endif; ?>

</body>

</html>