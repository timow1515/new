<?php
require_once('../config/auth.php');
require_once('navbar.php');
$event = first('events', ['event_id' => $_GET['event_id']]);
$categories = joinTable('event_category', [['events', 'events.event_id', 'event_category.event_id'], ['users', 'users.user_id', 'events.user_id']], ['events.event_id' => $_GET['event_id']]);

?>
<div class="container">
    <div class="row mx-auto">
        <div class="d-flex justify-content-between align-items-center">
            <h3 class="mt-3"><?= $event['title'] ?> <i>(<?php echo $event['event_status'] == 0 ? 'Ongoing' : ($event['event_status'] == 1 ? 'Results' : 'Done') ?>)</i></h3>
            <div class="back">
                <a href="home_lobby.php" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Back</a>
            </div>
        </div>
        <h5 class="mt-3">Categories</h5>

    </div>
    <div class="row mx-auto">
        <?php foreach ($categories as $row) { ?>
            <div class="col-md-4 mb-2">
                <div class="card rounded overflow-hidden">
                    <div class="card-head">
                        <div class="img-viewer">
                            <img class="img-view" src="<?= $row['banner'] ?>">
                        </div>
                    </div>
                    <div class="card-body px-4">
                        <div class="event-title"><?= $row['category_name'] ?> </div>
                        <div class="event-organizer"><strong>Organized by:</strong> <?= $row['firstname'] . ' ' . $row['lastname'] ?></div>
                        <div class="event-description"><strong> <?= $row['description'] ?></strong></div>
                        <div class="event-description"><strong>Payment: </strong>₱ <?= $row['payment_amount'] ?></div>
                        <div class="event-date"><strong>Date:</strong> <?php echo date('M d, Y h:i:s a', strtotime($row['date'])) ?></div>
                        <?php $checkmedin = first('participants', ['category_id' => $row['category_id'], 'user_id' => $_SESSION['user_id']]); ?>
                        <?php $count = countResult('participants', ['category_id' => $row['category_id']]); ?>
                        <div class="event-status"><strong>Participants: </strong><?= $count ?>/<?= $row['max_participants'] ?></div>
                        <div class="event-status"><strong>Status: </strong><?php echo $row['category_status'] == 0 ? 'Ongoing' : 'Result Posted' ?></div>
                        <?php if (!empty($checkmedin)) { ?>
                            <div><strong class="text-success">Joined</strong></div>
                        <?php } ?>
                        <div class="d-flex justify-content-center">
                            <?php if ($row['user_id'] == $_SESSION['user_id'] || empty($checkmedin)) { ?>
                                <?php if ($row['category_status'] == 0) { ?>
                                    <a class="btn btn-primary text-white px-5 mt-2" href="<?php echo $row['user_id'] == $_SESSION['user_id'] ? 'events_now.php?event_id=' . $row['event_id'] . '&category_id=' . $row['category_id'] : 'payments.php?event_id=' . $row['event_id'] . '&category_id=' . $row['category_id']; ?>"><?php echo $row['user_id'] == $_SESSION['user_id'] ? "Manage" : "Join" ?></a>
                                <?php } else { ?>
                                    <a href="../views/recent_events.php?category_id=<?php echo $row['category_id'] ?>&event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-info text-white px-5 mt-2">View Results</a>
                                <?php } ?>
                            <?php } else { ?>
                                <?php if ($row['category_status'] == 0) { ?>
                                    <a class="btn btn-primary text-white px-5 mt-2" href="events_now.php?event_id=<?= $row['event_id'] ?>&category_id=<?= $row['category_id'] ?>">View Entry</a>
                                <?php } else { ?>
                                    <a href="../views/recent_events.php?category_id=<?php echo $row['category_id'] ?>" class="btn btn-info text-white px-5 mt-2">View Results</a>
                                <?php } ?>
                            <?php } ?>

                        </div>
                    </div>
                </div>

            </div>
        <?php } ?>
    </div>

</div>
<?php require_once('footer.php'); ?>