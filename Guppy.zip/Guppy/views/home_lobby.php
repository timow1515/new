<?php
require_once('../config/auth.php');
require_once('navbar.php');

$user_id = $_SESSION['user_id'];

if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $query = "SELECT * FROM events
    INNER JOIN users ON users.user_id = events.user_id
    WHERE users.user_id = '$user_id' AND events.title LIKE '%$search%' AND DATE(events.date) >= '$start' AND DATE(events.date) <= '$end' AND events.event_status IN (0, 1)";
    $first = mysqli_query($conn, $query);
    $result = mysqli_fetch_all($first, MYSQLI_ASSOC);

    $query2 = "SELECT * FROM events
    INNER JOIN users ON users.user_id = events.user_id
    WHERE events.title LIKE '%$search%' AND DATE(events.date) >= '$start' AND DATE(events.date) <= '$end' AND events.event_status IN (0, 1)";
    $second = mysqli_query($conn, $query2);
    $other = mysqli_fetch_all($second, MYSQLI_ASSOC);

    $query3 = "SELECT * FROM events
    INNER JOIN users ON users.user_id = events.user_id
    INNER JOIN event_category ON event_category.event_id = events.event_id
    INNER JOIN participants ON participants.category_id = event_category.category_id
    WHERE events.title LIKE '%$search%' AND participants.user_id = '$user_id' AND DATE(events.date) >= '$start' AND DATE(events.date) <= '$end' AND events.event_status IN (0, 1)
    ORDER BY events.event_id";
    $third = mysqli_query($conn, $query3);
    $joined = mysqli_fetch_all($third, MYSQLI_ASSOC);

    $query4 = "SELECT * FROM events
    INNER JOIN users ON users.user_id = events.user_id
    WHERE events.title LIKE '%$search%' AND DATE(events.date) >= '$start' AND DATE(events.date) <= '$end' AND events.event_status IN (1, 2)";
    $fourth = mysqli_query($conn, $query4);
    $finished = mysqli_fetch_all($fourth, MYSQLI_ASSOC);
} else {
    $query = "SELECT * FROM events
    INNER JOIN users ON users.user_id = events.user_id
    WHERE users.user_id = '$user_id' AND DATE(events.date) >= '$start' AND DATE(events.date) <= '$end' AND events.event_status IN (0, 1)";
    $first = mysqli_query($conn, $query);
    $result = mysqli_fetch_all($first, MYSQLI_ASSOC);

    $query2 = "SELECT * FROM events
    INNER JOIN users ON users.user_id = events.user_id
    WHERE DATE(events.date) >= '$start' AND DATE(events.date) <= '$end' AND events.event_status IN (0, 1)";
    $second = mysqli_query($conn, $query2);
    $other = mysqli_fetch_all($second, MYSQLI_ASSOC);

    $query3 = "SELECT * FROM events
    INNER JOIN users ON users.user_id = events.user_id
    INNER JOIN event_category ON event_category.event_id = events.event_id
    INNER JOIN participants ON participants.category_id = event_category.category_id
    WHERE participants.user_id = '$user_id' AND DATE(events.date) >= '$start' AND DATE(events.date) <= '$end' AND events.event_status IN (0, 1)
    ORDER BY events.event_id";
    $third = mysqli_query($conn, $query3);
    $joined = mysqli_fetch_all($third, MYSQLI_ASSOC);

    $query4 = "SELECT * FROM events
    INNER JOIN users ON users.user_id = events.user_id
    WHERE DATE(events.date) >= '$start' AND DATE(events.date) <= '$end' AND events.event_status IN (1, 2)";
    $fourth = mysqli_query($conn, $query4);
    $finished = mysqli_fetch_all($fourth, MYSQLI_ASSOC);
    // $other = joinTableWherein('events', [['users', 'users.user_id', 'events.user_id']], ['events.event_status' => [0, 1]]);
    // $joined = joinTableWherein('events', [['users', 'users.user_id', 'events.user_id'], ['event_category', 'event_category.event_id', 'events.event_id'], ['participants', 'participants.category_id', 'event_category.category_id']], ['participants.user_id' => $_SESSION['user_id'], 'events.event_status' => [0, 1]], 'events.event_id');
    // $finished = joinTableWherein('events', [['users', 'users.user_id', 'events.user_id']], ['events.event_status' => [1, 2]]);
}

?>
<div class="container">
    <div class="row mx-auto">
        <div class="d-flex justify-content-between align-items-center flex-wrap">
            <div>
                <h3 class="mt-3"><i class="fa fa-fish"></i> Guppy Show Contest</h3>
                <p class="m-0">Filter: <?php echo date('M d Y', strtotime($start)) ?> to <?php echo date('M d Y', strtotime($end)) ?></p>
            </div>
            <form method="get" action="home_lobby.php">
                <div class="d-flex align-items-center flex-wrap">
                    <div class="d-flex align-items-center"><input class="form-control" type="search" name="search" value="<?php echo isset($_GET['search']) ? $_GET['search'] : '' ?>" placeholder="Search Events..."><button class="btn btn-primary text-light me-1" type="submit"><i class="fa fa-magnifying-glass"></i></button></div>
                    <input type="hidden" name="start" value="<?php echo $start ?>">
                    <input type="hidden" name="end" value="<?php echo $end ?>">
                    <button class="btn btn-secondary btn-sm px-4" type="button" data-bs-toggle="modal" data-bs-target="#filter"><i class="fa fa-filter"></i> Filter</button>
                </div>
            </form>
        </div>
        <div class="create-button">
            <a class="btn btn-primary text-light my-2" href="create_event.php">Create Event</a>
        </div>
    </div>
    <div class="row mx-auto">
        <h5 class="mt-4">Event you Created</h5>
        <?php if (empty($result)) : ?>
            <h6 class="text-secondary mb-5"><i>No Event Created</i></h6>
        <?php endif; ?>
        <?php foreach ($result as $row) { ?>
            <div class="col-md-4 mb-2">
                <div class="card rounded">
                    <div class="card-head">
                        <div class="img-viewer">
                            <img class="img-view" src="<?= $row['banner'] ?>">
                        </div>
                    </div>
                    <div class="card-body px-4">
                        <div class="event-title"><?= $row['title'] ?> </div>
                        <div class="event-organizer"><strong>Organized by:</strong> <?= $row['firstname'] . ' ' . $row['lastname'] ?></div>
                        <div class="event-description"><strong> <?= $row['description'] ?></strong></div>
                        <div class="event-date"><strong>Date:</strong> <?php echo date('M d, Y h:i:s a', strtotime($row['date'])) ?></div>
                        <div class="event-status"><strong>Status: </strong><?php echo $row['event_status'] == 0 ? 'Ongoing' : ($row['event_status'] == 1 ? 'Results' : 'Done') ?></div>
                        <div class="d-flex justify-content-center">
                            <a class="btn btn-primary text-white px-5 mt-2" href="event_detail.php?event_id=<?= $row['event_id'] ?>">View</a>
                        </div>
                    </div>
                </div>

            </div>
        <?php } ?>
    </div>

    <div class="row mx-auto mb-3">
        <h5 class="mt-4">Events On Going</h5>
        <?php if (empty($other)) : ?>
            <h6 class="text-secondary mb-5"><i>No Event On Going</i></h6>
        <?php endif; ?>
        <?php foreach ($other as $row) { ?>
            <div class="col-md-4 mb-2">
                <div class="card rounded">
                    <div class="card-head">
                        <div class="img-viewer">
                            <img class="img-view" src="<?= $row['banner'] ?>">
                        </div>
                    </div>
                    <div class="card-body px-4">
                        <div class="event-title"><?= $row['title'] ?> </div>
                        <div class="event-organizer"><strong>Organized by:</strong> <?= $row['firstname'] . ' ' . $row['lastname'] ?></div>
                        <div class="event-description"><strong> <?= $row['description'] ?></strong></div>
                        <div class="event-date"><strong>Date:</strong> <?php echo date('M d, Y h:i:s a', strtotime($row['date'])) ?></div>
                        <div class="event-status"><strong>Status: </strong><?php echo $row['event_status'] == 0 ? 'Ongoing' : ($row['event_status'] == 1 ? 'Results' : 'Done') ?></div>
                        <div class="d-flex justify-content-center">
                            <a class="btn btn-primary text-white px-5 mt-2" href="event_detail.php?event_id=<?= $row['event_id'] ?>">View</a>
                        </div>
                    </div>
                </div>

            </div>
        <?php } ?>
    </div>

    <div class="row mx-auto mb-3">
        <h5 class="mt-4">Events You Joined</h5>
        <?php if (empty($joined)) : ?>
            <h6 class="text-secondary mb-5"><i>No Event Joined</i></h6>
        <?php endif; ?>
        <?php foreach ($joined as $row) { ?>
            <div class="col-md-4 mb-2">
                <div class="card rounded">
                    <div class="card-head">
                        <div class="img-viewer">
                            <img class="img-view" src="<?= $row['banner'] ?>">
                        </div>
                    </div>
                    <div class="card-body px-4">
                        <div class="event-title"><?= $row['title'] ?> </div>
                        <div class="event-organizer"><strong>Organized by:</strong> <?= $row['firstname'] . ' ' . $row['lastname'] ?></div>
                        <div class="event-description"><strong> <?= $row['description'] ?></strong></div>
                        <div class="event-date"><strong>Date:</strong> <?php echo date('M d, Y h:i:s a', strtotime($row['date'])) ?></div>
                        <div class="event-status"><strong>Status: </strong><?php echo $row['event_status'] == 0 ? 'Ongoing' : ($row['event_status'] == 1 ? 'Results' : 'Done') ?></div>
                        <div class="d-flex justify-content-center">
                            <a class="btn btn-primary text-white px-5 mt-2" href="event_detail.php?event_id=<?= $row['event_id'] ?>">View</a>
                        </div>
                    </div>
                </div>

            </div>
        <?php } ?>
    </div>
    <div class="row mx-auto mb-3">
        <h5 class="mt-4">Recent Events</h5>
        <?php if (empty($finished)) : ?>
            <h6 class="text-secondary mb-5"><i>No Recent Finish Events</i></h6>
        <?php endif; ?>
        <?php foreach ($finished as $row) { ?>
            <div class="col-md-4 mb-2">
                <div class="card rounded">
                    <div class="card-head">
                        <div class="img-viewer">
                            <img class="img-view" src="<?= $row['banner'] ?>">
                        </div>
                    </div>
                    <div class="card-body px-4">
                        <div class="event-title"><?= $row['title'] ?> </div>
                        <div class="event-organizer"><strong>Organized by:</strong> <?= $row['firstname'] . ' ' . $row['lastname'] ?></div>
                        <div class="event-description"><strong> <?= $row['description'] ?></strong></div>
                        <div class="event-date"><strong>Date:</strong> <?php echo date('M d, Y h:i:s a', strtotime($row['date'])) ?></div>
                        <div class="event-status"><strong>Status: </strong><?php echo $row['event_status'] == 0 ? 'Ongoing' : ($row['event_status'] == 1 ? 'Results' : 'Done') ?></div>
                        <div class="d-flex justify-content-center">
                            <a class="btn btn-primary text-white px-5 mt-2" href="event_detail.php?event_id=<?= $row['event_id'] ?>">View</a>
                        </div>
                    </div>
                </div>

            </div>
        <?php } ?>
    </div>
</div>

<!-- Filter Modal -->
<div class="modal fade" id="filter" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel"><i class="fa fa-filter"></i> Filter</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="get" action="home_lobby.php">
                <div class="modal-body">
                    <div class="form-group mb-2">
                        <label>Date From:</label>
                        <input class="form-control" required value="<?php echo isset($_GET['start']) ? $_GET['start'] : $start ?>" name="start" type="date">
                    </div>
                    <div class="form-group">
                        <label>Date To:</label>
                        <input class="form-control" required value="<?php echo isset($_GET['end']) ? $_GET['end'] : $end ?>" name="end" type="date">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                    <button type="submit" class="btn btn-primary px-4 text-light"><i class="fa fa-filter"></i> Filter</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>