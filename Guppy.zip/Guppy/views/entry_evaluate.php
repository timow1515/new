<?php require_once('navbar.php'); ?>
<?php $entry = firstJoin('entries', [['users', 'users.user_id', 'entries.user_id']], ['entries.entry_id' => $_GET['entry_id']]); ?>
<?php $firstvideo = first('entries_video', ['entry_id' => $_GET['entry_id']]); ?>
<?php $firstimage = first('entries_image', ['entry_id' => $_GET['entry_id']]); ?>
<?php $check_badge = first('evaluation', ['entry_id' => $_GET['entry_id']]); ?>
<div class="container">
    <div class="row mx-auto my-3">
        <div class="back">
            <a href="events_now.php?event_id=<?php echo $_GET['event_id'] ?>&category_id=<?php echo $_GET['category_id'] ?>" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Back</a>
        </div>
    </div>
    <div class="row mx-auto my-3">
        <div class="card border-0 shadow border">
            <div class="card-body">
                <div class="d-flex align-items-center ">
                    <div class="post-profile me-1">
                        <img class="img-comments" src="<?php echo $entry['profile_picture'] != null ? $entry['profile_picture'] : '../public/assets/images/user.jpg' ?>">
                    </div>
                    <div class="d-flex align-items-center">
                        <p class="m-0"><?= $entry['firstname'] . ' ' . $entry['lastname'] ?></p>
                        <p class="m-0"> <i>(<strong>Entry Code:</strong> <?= $entry['entry_code'] ?>)</i></p>
                    </div>
                </div>
                <div class="d-flex align-items-center">
                    <?php if (!empty($check_badge) && $check_badge['evaluation_badge'] != 0) : ?>
                        <div class="post-profile me-1 mt-1">
                            <img class="badgerist" src="<?php echo !empty($check_badge) && $check_badge['evaluation_badge'] == 1 ? '../public/assets/images/badge/first.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 2 ? '../public/assets/images/badge/second.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 3 ? '../public/assets/images/badge/third.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 4 ? '../public/assets/images/badge/fourth.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 5 ? '../public/assets/images/badge/fifth.png' :  '../public/assets/images/badge/default.png')))) ?>">
                        </div>
                        <p class="m-0"><?php echo !empty($check_badge) && $check_badge['evaluation_badge'] == 1 ? '1st Place' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 2 ? '2nd Place' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 3 ? '3rd Place' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 4 ? '4th Place' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 5 ? '5th Place' :  'Error')))) ?></p>
                    <?php endif; ?>
                </div>

                <div class="row mx-auto mt-1 p-0 labelscaption" id="labelscaption<?php echo $_GET['entry_id'] ?>" entrayy-id="<?php echo $_GET['entry_id'] ?>">
                    <!-- Send by Ajax Content -->
                </div>
                <div class="row mt-1">
                    <div class="col-md-9 preview-container border shadow rounded" style="height: 686px;">
                        <video controls class="wideos">
                            <source src="<?= $firstvideo['entry_video_file'] ?>" type="video/mp4">
                        </video>
                    </div>
                    <div class="col-md-3">
                        <?php
                        $countVid = countResult('entries_video', ['entry_id' => $_GET['entry_id']]);
                        ?>
                        <?php if ($countVid > 0) : ?>
                            <div class="row px-0 position-relative" style="height: 50%;">
                                <div class="img-evaluate-cont">
                                    <img class="img-evaluate blured" src="../public/assets/images/video-placeholder.jpg">
                                </div>
                                <h5 class="count-display text-center cursor-pointer" data-bs-toggle="modal" data-bs-target="#videos_previews">
                                    <i class="fa fa-plus"></i><?php echo $countVid - 1; ?> more videos<br><br>
                                    <i class="fa fa-eye"></i> View All Videos
                                </h5>
                            </div>
                        <?php endif; ?>
                        <?php
                        $countImg = countResult('entries_image', ['entry_id' => $_GET['entry_id']]);
                        ?>
                        <?php if ($countImg > 0) : ?>
                            <div class="row px-0 mt-1 position-relative" style="height: 49%;">
                                <div class="img-evaluate-cont">
                                    <img class="img-evaluate blured" src="<?= $firstimage['entry_image_file'] ?>">
                                </div>
                                <h5 class="count-display text-center cursor-pointer" data-bs-toggle="modal" data-bs-target="#img-previews">
                                    <i class="fa fa-plus"></i><?php echo $countImg; ?> images<br><br>
                                    <i class="fa fa-eye"></i> View All Images
                                </h5>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <?php $checkingStats = first('event_category', ['category_id' => $_GET['category_id'], 'category_status' => 1]); ?>
                    <?php if (empty($checkingStats)) { ?>
                        <button class="btn btn-secondary btn-sm py-1 evaluate" type="button" data-bs-toggle="modal" data-bs-target="#evaluate"><i class="fa fa-ribbon"></i> Evaluate</button>
                    <?php } else { ?>
                        <button class="btn btn-secondary btn-sm py-1 evaluate px-4" type="button" disabled> N/A</button>
                    <?php } ?>

                    <div class="ms-1 container-evaluate d-flex justify-content-center align-items-center border border-info shadow">
                        <img class="img-badge" src="<?php echo !empty($check_badge) && $check_badge['evaluation_badge'] == 1 ? '../public/assets/images/badge/first.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 2 ? '../public/assets/images/badge/second.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 3 ? '../public/assets/images/badge/third.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 4 ? '../public/assets/images/badge/fourth.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 5 ? '../public/assets/images/badge/fifth.png' :  '../public/assets/images/badge/default.png')))) ?>">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Video -->
<div class="modal fade px-0" id="videos_previews" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content bg-transparent">
            <div class="modal-header transparent mt-2">
                <button type="button" class="btn btn-secondary text-light" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close </button>
            </div>
            <div class="modal-body p-0 pb-2">
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <?php $video = find_where('entries_video', ['entry_id' => $_GET['entry_id']]); ?>
                        <?php foreach ($video as $videos) : ?>
                            <div class="swiper-slide">
                                <video controls class="wideos">
                                    <source src="<?= $videos['entry_video_file'] ?>" type="video/mp4">
                                </video>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Image -->
<div class="modal fade px-0" id="img-previews" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content bg-transparent">
            <div class="modal-header transparent mt-2">
                <button type="button" class="btn btn-secondary text-light" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close </button>
            </div>
            <div class="modal-body p-0 pb-2">
                <div class="swiper mySwiper">
                    <div class="swiper-wrapper">
                        <?php $imgs = find_where('entries_image', ['entry_id' => $_GET['entry_id']]);
                        foreach ($imgs as $images) :
                        ?>
                            <div class="swiper-slide">
                                <img class="img-preview-modal" src="<?= $images['entry_image_file'] ?>">
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Modal Evaluate -->

<div class="modal fade" id="evaluate" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Evaluate <?= $entry['firstname'] . ' ' . $entry['lastname'] ?> Entry <br>
                    <i class="ms-1" style="font-size:13px"> (Entry Code: <strong><?= $entry['entry_code'] ?></strong>)</i>
                </h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" action="../actions/evaluate.php">
                <input type="hidden" name="entry_id" value="<?php echo $_GET['entry_id'] ?>">
                <input type="hidden" name="event_id" value="<?php echo $_GET['event_id'] ?>">
                <input type="hidden" name="category_id" value="<?php echo $_GET['category_id'] ?>">
                <div class="modal-body">
                    <div class="row mx-auto mb-3">
                        <div class="col-md-6">
                            <div class="form-check">
                                <?php $checkPlace1 = first('evaluation', ['entry_id' => $_GET['entry_id'], 'evaluation_badge' => 1]); ?>
                                <input <?php echo !empty($checkPlace1) ? 'disabled' : 'checked'; ?> class="form-check-input" type="radio" name="placement" value="1" id="flexRadioDefault1">
                                <label class="form-check-label" for="flexRadioDefault1">
                                    1st Place
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <?php $checkPlace2 = first('evaluation', ['entry_id' => $_GET['entry_id'], 'evaluation_badge' => 2]); ?>
                                <input <?php echo !empty($checkPlace2) ? 'disabled' : ''; ?> class="form-check-input" type="radio" name="placement" value="2" id="flexRadioDefault2">
                                <label class="form-check-label" for="flexRadioDefault2">
                                    2nd Place
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row mx-auto mb-3">
                        <div class="col-md-6">
                            <div class="form-check">
                                <?php $checkPlace3 = first('evaluation', ['entry_id' => $_GET['entry_id'], 'evaluation_badge' => 3]); ?>
                                <input <?php echo !empty($checkPlace3) ? 'disabled' : ''; ?> class="form-check-input" type="radio" name="placement" value="3" id="flexRadioDefault3">
                                <label class="form-check-label" for="flexRadioDefault3">
                                    3rd Place
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <?php $checkPlace4 = first('evaluation', ['entry_id' => $_GET['entry_id'], 'evaluation_badge' => 4]); ?>
                                <input <?php echo !empty($checkPlace4) ? 'disabled' : ''; ?> class="form-check-input" type="radio" name="placement" value="4" id="flexRadioDefault4">
                                <label class="form-check-label" for="flexRadioDefault4">
                                    4th Place
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row mx-auto">
                        <div class="col-md-6">
                            <div class="form-check">
                                <?php $checkPlace5 = first('evaluation', ['entry_id' => $_GET['entry_id'], 'evaluation_badge' => 5]); ?>
                                <input <?php echo !empty($checkPlace5) ? 'disabled' : ''; ?> class="form-check-input" type="radio" name="placement" value="5" id="flexRadioDefault5">
                                <label class="form-check-label" for="flexRadioDefault5">
                                    5th Place
                                </label>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="placement" value="0" id="flexRadioDefault5">
                                <label class="form-check-label" for="flexRadioDefault5">
                                    Default
                                </label>
                            </div>
                        </div>
                        <div class="row mx-auto mt-3 p-0 labels" id="labels<?php echo $_GET['entry_id'] ?>" entry-id="<?php echo $_GET['entry_id'] ?>">
                            <!-- Send by Ajax Content -->
                        </div>
                        <div class="row mx-auto mt-3 p-0" id="row-cloned<?php echo $_GET['entry_id'] ?>">
                            <div id="row-of-form<?php echo $_GET['entry_id'] ?>" class="col-md-12 px-0 mb-1">
                                <div class="form-group">
                                    <label>Label</label>
                                    <div class="d-flex align-items-center position-relative justify-content-between g-0">
                                        <input class="form-control" placeholder="Best in ..." name="label[]" id="label<?php echo $_GET['entry_id'] ?>">
                                        <i class="fa fa-times remove text-danger cursor-pointer position-absolute" style="display: none; right:0; margin-right:10px"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group d-flex justify-content-end mb-3 px-0">
                            <button class="btn btn-secondary btn-sm text-light addlabel" type="button" id="addlabel<?php echo $_GET['entry_id'] ?>" entroy-id="<?php echo $_GET['entry_id'] ?>"><i class="fa fa-plus-circle text-size"></i> Label</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="evaluate" class="btn btn-primary text-light">Evaluate</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>