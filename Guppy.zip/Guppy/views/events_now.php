<?php
require_once('../config/auth.php');
require_once('navbar.php');
$check = first('entries', ['category_id' => $_GET['category_id'], 'user_id' => $_SESSION['user_id']]);
// var_dump($check['entry_id']);
if (!empty($check)) {
    $count = countResult('entries_video', ['entry_id' => $check['entry_id']]);
}
// var_dump($count);
$events = joinTable('events', [['users', 'users.user_id', 'events.user_id'], ['event_category', 'event_category.event_id', 'events.event_id']], ['event_category.category_id' => $_GET['category_id'], 'events.user_id' => $_SESSION['user_id']]);
$user = first('users', ['user_id' => $_SESSION['user_id']]);
?>
<div class="container position-relative" id="container-evaluate">
    <div class="row mx-auto mb-3">
        <div class="d-flex justify-content-between mt-2">
            <div class="back">
                <a href="event_detail.php?event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Back</a>
            </div>
            <?php if (empty($events)) : ?>
                <?php if ($count <= 0) { ?>
                    <h6 class="m-0 me-1 "><i>Looks like you are a participant and didn`t upload a video</i></h6>

                    <div class="form-group">
                        <a href="uploadVideos.php?event_id=<?php echo $_GET['event_id'] ?>&category_id=<?php echo $_GET['category_id'] ?>" class="btn btn-primary text-light">Add Video</a>
                    </div>
                <?php } ?>
            <?php endif; ?>
            <?php if (!empty($events)) : ?>
                <?php $showReport = firstJoin('entries', [['evaluation', 'entries.entry_id', 'evaluation.entry_id']], ['entries.category_id' => $_GET['category_id']]); ?>
                <?php if (!empty($showReport)) : ?>
                    <?php $checkingStats = first('event_category', ['category_id' => $_GET['category_id'], 'category_status' => 1]); ?>
                    <?php if (empty($checkingStats)) { ?>
                        <a href="../actions/event.php?PostResult&category_id=<?php echo $_GET['category_id'] ?>&event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-info text-light"><i class="fa fa-check"></i> Post Results</a>
                    <?php } else { ?>
                        <h4><i class="fa fa-check"></i> Result Posted</h4>
                    <?php }  ?>

                <?php endif; ?>
                <?php if (empty($checkingStats)) : ?>
                    <a href="addparticipants.php?category_id=<?php echo $_GET['category_id'] ?>&event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-primary text-light"><i class="fa fa-plus-circle"></i> Participants</a>
                <?php endif; ?>
            <?php endif; ?>

        </div>
    </div>
    <?php if (!empty($check) && $count > 0) {
        $categories = firstJoin('event_category', [['events', 'events.event_id', 'event_category.event_id']], ['events.event_id' => $_GET['event_id'], 'category_id' => $_GET['category_id']]);
    ?>

        <div class="row mx-auto">
            <h3>Your Entry on <?= $categories['title'] ?> (<?= $categories['category_name'] ?> Category)</h3>
        </div>
        <?php $video = find_where('entries_video', ['entry_id' => $check['entry_id']]); ?>
        <?php $videofirst = first('entries_video', ['entry_id' => $check['entry_id']]); ?>
        <div class="row mx-auto my-3">
            <div class="col-md-7">
                <div class="m-0 mt-1 p-0 mb-2 d-flex align-items-center">
                    <div class="profile">
                        <img class="img-view" src="<?php echo $_SESSION['profile_picture'] != null ? $_SESSION['profile_picture'] : '../public/assets/images/user.jpg' ?>">
                    </div>
                    <p class="m-0 ms-1"><?= $user['firstname'] . ' ' . $user['lastname'] ?> (You)</p>
                </div>
                <div class="row mx-auto">
                    <div class="<?php echo $count > 1 ? 'col-md-7' : 'col-md-12' ?> px-0">
                        <div class="preview-containers col-md-12 border shadow rounded px-0 mx-0">
                            <video controls class="wideos">
                                <source src="<?= $videofirst['entry_video_file'] ?>" type="video/mp4">
                            </video>
                        </div>
                    </div>
                    <?php if ($count > 1) : ?>
                        <div class="col-md-5 px-0 position-relative">
                            <h5 class="count-display text-center cursor-pointer" data-bs-toggle="modal" data-bs-target="#videos_previews">
                                <i class="fa fa-plus"> </i><?php echo $count - 1; ?> more videos </br></br>
                                <i class="fa fa-eye"></i> View All Videos
                            </h5>
                            <img class="img-view-now blured" src="../public/assets/images/video-placeholder.jpg">
                        </div>


                        <div class="modal fade px-0" id="videos_previews" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-fullscreen">
                                <div class="modal-content bg-transparent">
                                    <div class="modal-header transparent mt-2">
                                        <button type="button" class="btn btn-secondary text-light" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close </button>
                                    </div>
                                    <div class="modal-body p-0 pb-2">
                                        <div class="swiper mySwiper">
                                            <div class="swiper-wrapper">
                                                <?php foreach ($video as $videos) : ?>
                                                    <div class="swiper-slide">
                                                        <video controls class="wideos">
                                                            <source src="<?= $videos['entry_video_file'] ?>" type="video/mp4">
                                                        </video>
                                                    </div>
                                                <?php endforeach; ?>
                                            </div>
                                            <div class="swiper-button-next"></div>
                                            <div class="swiper-button-prev"></div>
                                            <div class="swiper-pagination"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endif; ?>
                </div>
                <?php $image_first = first('entries_image', ['entry_id' => $check['entry_id']]); ?>
                <?php if (!empty($image_first)) : ?>
                    <h5 class="mx-0 px-0">Images</h5>
                    <div class="row mx-auto mt-1">
                        <div class="col-md-6  px-0">
                            <img class="img-view-now cursor-pointer" data-bs-toggle="modal" data-bs-target="#pictures_previews" src="<?= $image_first['entry_image_file'] ?>">
                        </div>
                        <?php $count_image = countResult('entries_image', ['entry_id' => $check['entry_id']]); ?>
                        <?php if ($count_image > 0) : ?>
                            <div class="col-md-6  px-0 position-relative">
                                <h5 class="count-display text-center cursor-pointer" data-bs-toggle="modal" data-bs-target="#pictures_previews">
                                    <i class="fa fa-plus"> </i><?php echo $count_image - 1; ?> more images </br></br>
                                    <i class="fa fa-eye"></i> View All Images
                                </h5>
                                <img class="img-view-now blured" src="<?= $image_first['entry_image_file'] ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="modal fade px-0" id="pictures_previews" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-fullscreen">
                <div class="modal-content bg-transparent">
                    <div class="modal-header transparent mt-2">
                        <button type="button" class="btn btn-secondary text-light" data-bs-dismiss="modal"><i class="fa fa-times"></i> Close </button>
                    </div>
                    <div class="modal-body p-0 pb-2">
                        <div class="swiper mySwiper">
                            <div class="swiper-wrapper">
                                <?php $imgs = find_where('entries_image', ['entry_id' => $check['entry_id']]);
                                foreach ($imgs as $images) :
                                ?>
                                    <div class="swiper-slide">
                                        <img class="img-preview-modal" src="<?= $images['entry_image_file'] ?>">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="swiper-button-next"></div>
                            <div class="swiper-button-prev"></div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php } else if (!empty($check) && $count == 0) {
    } else { ?>
        <?php $entries = joinTable('events', [['event_category', 'event_category.event_id', 'events.event_id'], ['participants', 'participants.category_id', 'event_category.category_id'], ['users', 'users.user_id', 'participants.user_id'], ['entries', 'entries.user_id', 'participants.user_id']], ['event_category.category_id' => $_GET['category_id'], 'entries.category_id' => $_GET['category_id'], 'participants.category_id' => $_GET['category_id']]);
        $categories = firstJoin('event_category', [['events', 'events.event_id', 'event_category.event_id']], ['events.event_id' => $_GET['event_id'], 'category_id' => $_GET['category_id']]);
        ?>
        <div class="row mx-auto">
            <h3>Entries on <?= $categories['title'] ?> (<?= $categories['category_name'] ?> Category)</h3>
        </div>
        <div class="row mx-auto">
            <div class="card border-0 border p-5 shadow">
                <div class="card-body">
                    <table class="table" id="table">
                        <thead>
                            <tr>
                                <th class="d-none"></th>
                                <th>Participants</th>
                                <th>Email</th>
                                <th>Contact</th>
                                <th>Evaluation</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $index = 0; ?>
                            <?php foreach ($entries as $row) : ?>
                                <?php $check_badge = first('evaluation', ['entry_id' => $row['entry_id']]); ?>
                                <tr>
                                    <td class="d-none"><?php echo !empty($check_badge) && $check_badge['evaluation_badge'] == 1 ? 1 : (!empty($check_badge) && $check_badge['evaluation_badge'] == 2 ? 2 : (!empty($check_badge) && $check_badge['evaluation_badge'] == 3 ? 3 : (!empty($check_badge) && $check_badge['evaluation_badge'] == 4 ? 4 : (!empty($check_badge) && $check_badge['evaluation_badge'] == 5 ? 5 : 999 + $index))));
                                                        $index++; ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <img class="img-entr me-1" src="<?php echo $row['profile_picture'] != null ? $row['profile_picture'] : '../public/assets/images/user.jpg' ?>" />
                                            <p class="m-0"><?= $row['firstname'] . ' ' . $row['lastname'] ?></p>
                                        </div>
                                    </td>
                                    <td>
                                        <?= $row['email'] ?>
                                    </td>
                                    <td>
                                        <?= $row['contact_number'] ?>
                                    </td>
                                    <td>
                                        <?php if (empty($check_badge) || $check_badge['evaluation_badge'] == 0) { ?>
                                            <p class="m-0">None</p>
                                        <?php } else { ?>
                                            <img class="img-badgesss" src="<?php echo !empty($check_badge) && $check_badge['evaluation_badge'] == 1 ? '../public/assets/images/badge/first.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 2 ? '../public/assets/images/badge/second.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 3 ? '../public/assets/images/badge/third.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 4 ? '../public/assets/images/badge/fourth.png' : (!empty($check_badge) && $check_badge['evaluation_badge'] == 5 ? '../public/assets/images/badge/fifth.png' :  '../public/assets/images/badge/default.png')))) ?>">
                                        <?php } ?>
                                    </td>
                                    <td><a href="./entry_evaluate.php?event_id=<?php echo $_GET['event_id'] ?>&category_id=<?php echo $_GET['category_id'] ?>&entry_id=<?= $row['entry_id'] ?>" class="btn btn-primary text-light"><i class="fa fa-eye"></i> View Entry</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php } ?>
</div>
<?php require_once('footer.php'); ?>