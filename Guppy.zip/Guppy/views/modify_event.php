<?php
require_once('navbar.php');
$event = first('events', ['event_id' => $_GET['event_id']]);

?>

<div class="col-md-6 mx-auto border shadow rounded my-4 p-5 bg-white">
    <h3>Modify Event</h3>
    <form action="../actions/event.php" method="POST">
        <input type="hidden" name="event_id" value="<?php echo $event['event_id']; ?>">
        <div class="form-group mb-3">
            <label for="title">Title:</label>
            <input type="text" id="title" class="form-control" name="title" value="<?php echo $event['title']; ?>">
        </div>
        <div class="form-group">
            <label for="event_description">Event Description:</label>
            <textarea id="event_description" class="form-control" style="height: 100px;" name="event_description"><?php echo $event['description']; ?></textarea>
        </div>
        <div class="form-group">
            <div class="row mx-auto">
                <input type="submit" class="btn btn-primary text-light mt-3" name="modify" value="Save Changes">
            </div>
        </div>
    </form>
</div>
<?php require_once('footer.php'); ?>