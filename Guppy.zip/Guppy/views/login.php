<?php
require_once('../config/config.php');
require_once('../config/noauth.php');
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="favicon.ico" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css" />
    <script defer src="../public/assets/plugins/fontawesome/js/all.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link id="theme-style" rel="stylesheet" href="../public/assets/css/portal.css" />
    <link rel="stylesheet" href="../public/assets/fullcalendar/fullcalendar.min.css" />
    <link id="theme-style" rel="stylesheet" href="../public/assets/css/style.css" />
    <title>Login</title>
</head>

<body class="bg-secondary">
    <div class="col-md-4 shadow border rounded mt-5 mx-auto p-5 bg-light">
        <h4>Guppy Show Contest</h4>
        <form method="POST" action="../actions/login.php">
            <div class="form-group mb-2">
                <label>Email</label>
                <input type="email" class="form-control" name="email" value="<?php echo getValue('email'); ?>" placeholder="Email" required>
                <?php if (showError('email')) :
                    echo showError('email');
                endif; ?>
            </div>

            <div class="form-group mb-3">
                <label>Password</label>
                <input type="password" class="form-control" name="password" placeholder="Password" required>
                <?php if (showError('password')) :
                    echo showError('password');
                endif; ?>
            </div>
            <div class="form-group">
                <div class="row mx-auto">
                    <button type="submit" class="btn btn-primary text-light" name="login">Login</button>
                    <p class="text-center">Don't have an account? <a href="register.php">Register</a></p>
                </div>
            </div>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script src="../public/assets/plugins/popper.min.js"></script>
    <script src="../public/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="../public/assets/plugins/chart.js/chart.min.js"></script>
    <script src="../public/assets/js/index-charts.js"></script>
    <script src="../public/assets/js/app.js"></script>
    <script src="../public/assets/js/main.js"></script>

    <?php if ($flash = getFlash('failed')) : ?>
        <script>
            Swal.fire({
                icon: 'warning',
                title: "<?php echo $flash; ?>",
                showConfirmButton: true,
            });
        </script>
    <?php endif; ?>

</body>

</html>