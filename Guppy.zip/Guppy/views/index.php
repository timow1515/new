<?php
require_once('../config/config.php');
redirect('login');
