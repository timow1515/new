<?php
require_once('../config/auth.php');
require_once('navbar.php');
$event = first('events', ['event_id' => $_GET['event_id']]);
$history = joinTable('event_category', [['events', 'events.event_id', 'event_category.event_id']], ['events.event_id' => $_GET['event_id']]);
?>
<div class="container">
    <div class="row mx-auto mt-3">
        <div class="col-md-12">
            <div class="card border-0 shadow border p-4">
                <div class="card-header bg-white pt-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h3 class=""><i class="fa fa-calendar"></i> Categories of <?= $event['title'] ?></h3>
                        <div class="back">
                            <a href="eventhistory.php" class="btn btn-secondary px-4"><i class="fa fa-arrow-left"></i> Back</a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table" id="table">
                        <thead>
                            <tr>
                                <th class="d-none"></th>
                                <th>Event Title</th>
                                <th>Event Category</th>
                                <th>Payment</th>
                                <th>Date</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($history as $row) : ?>
                                <tr>
                                    <td class="d-none"><?php echo $no;
                                                        $no++; ?></td>
                                    <td><?= $row['title'] ?></td>
                                    <td><?= $row['category_name'] ?></td>
                                    <td>₱ <?= $row['payment_amount'] ?></td>
                                    <td><?php echo date('M d, Y h:i:s a', strtotime($row['date'])); ?></td>
                                    <td><a href="category_details.php?category_id=<?= $row['category_id'] ?>&event_id=<?php echo $_GET['event_id'] ?>" class="btn btn-primary text-light px-4"><i class="fa fa-eye"></i> View</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php require_once('footer.php'); ?>