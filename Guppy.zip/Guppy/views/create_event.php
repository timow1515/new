<?php
require_once('../config/auth.php');
require_once('navbar.php');
?>

<body>
    <div class="col-md-8 mx-auto border shadow rounded my-3 p-5" style="background-color: #fff;">
        <h3 class="mb-3"><i class="fa fa-calendar"></i> Create Event</h3>
        <form method="POST" action="../actions/event.php" enctype="multipart/form-data">
            <div class="profile-circle mx-auto border my-3" id="image-container">
                <img id="preview-image" src="../public/assets/images/2616533-200.png" alt=" Preview Image">
            </div>
            <div class="form-group mb-2">
                <label>Banner</label>
                <input type="file" id="image-upload" name="banner" class="form-control" accept="image/*" required>
            </div>
            <div class="form-group mb-3">
                <label for="title">Title:</label>
                <input class="form-control" type="text" name="title" id="title" required>
            </div>

            <div class="form-group mb-3">
                <label for="description">Description:</label>
                <textarea class="form-control" style="height: 100px;" name="description" id="description" required></textarea>
            </div>

            <div class="form-group mb-3">
                <label for="max_participants">Date of Event:</label>
                <input class="form-control" type="datetime-local" name="date" id="date" required>
            </div>
            <div class="row mx-auto mx-auto p-0" id="row-cloned">
                <div id="row-of-form" class="col-md-12 px-0 mb-1">
                    <div class="form-group">
                        <div class="d-flex align-items-center position-relative justify-content-between g-0">
                            <div class="col-md-4 me-1">
                                <div class="form-group">
                                    <label for="category">Category:</label>
                                    <input class="form-control category" type="text" name="category[]" id="category" required>
                                </div>
                            </div>
                            <div class="col-md-4 me-1">
                                <div class="form-group">
                                    <label for="category">Payment Amount:</label>
                                    <input class="form-control payment" type="number" name="payment[]" step="0.01" id="payment" required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="category">Max Participants:</label>
                                    <input class="form-control max_participants" type="number" name="max_participants[]" id="max_participants" required>
                                </div>
                            </div>
                            <i class="fa fa-times remove text-danger cursor-pointer position-absolute mt-4" style="display: none; right:0; margin-right:10px"></i>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group d-flex justify-content-end mb-3 px-0">
                <button class="btn btn-primary btn-sm text-light" type="button" id="add"><i class="fa fa-plus-circle text-size"></i> Category</button>
            </div>
            <div class="form-group">
                <div class="row mx-auto">
                    <button class="btn btn-primary text-light" type="submit" name="create_event">Create</button>
                </div>
            </div>
        </form>

        <div class="d-flex justify-content-center mt-3">
            <a class="text-dark text-center" href="home_lobby.php">Cancel</a>
        </div>
    </div>
    <?php require_once('footer.php'); ?>