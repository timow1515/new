<?php
//dont use this nonsense
$public = "../public";
$img = "../public/assets/img";
$config = "../config";
$library = "../library";
$actions = "../actions";
$queries = "../queries";
$views = "../views";
$config = "../config";
$bootstrapcss = "../public/assets/bootstrap/css/bootstrap.min.css"; //default route for bootstrap css
$bootstrapjs = "../public/assets/bootstrap/js/bootstrap.min.js"; //default route for bootstrap js
$icons = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"; //default url for font-awesome icons
$style = "../public/assets/css/style.css"; //routes for style
$jquery = "../public/assets/js/jquery-3.6.0.min.js"; //routes for style
$mainjs = "../public/assets/js/main.js"; //routes for style
